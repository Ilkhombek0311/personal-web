var typed = new Typed(".multiple-text", {
    strings: ["Back-end Dasturchisiman", "Telegram-bot Dasturchisiman"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true,
})